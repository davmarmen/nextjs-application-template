import { fabric } from 'fabric';
import * as THREE from 'three';

class DesignLab {
    constructor() {
        this.currentStep = 1;
        this.userType = null;
        this.selectedProduct = null;
        this.canvas = null;
        this.scene = null;
        this.renderer = null;
        this.camera = null;
        this.designData = null;
        
        // Real-world product dimensions and pricing
        this.productSpecs = {
            // Lanyards 1 cara
            'lanyard-15-1': { 
                mm: { width: 900, height: 15 }, 
                px: { width: 10630, height: 177 },
                safeArea: { top: 25, bottom: 25, left: 1.5, right: 1.5 },
                price: 3.50,
                name: 'Lanyard 15mm (1 cara)'
            },
            'lanyard-20-1': { 
                mm: { width: 900, height: 20 }, 
                px: { width: 10630, height: 236 },
                safeArea: { top: 25, bottom: 25, left: 1.5, right: 1.5 },
                price: 3.75,
                name: 'Lanyard 20mm (1 cara)'
            },
            'lanyard-25-1': { 
                mm: { width: 900, height: 25 }, 
                px: { width: 10630, height: 295 },
                safeArea: { top: 25, bottom: 25, left: 1.5, right: 1.5 },
                price: 4.00,
                name: 'Lanyard 25mm (1 cara)'
            },
            // Lanyards 2 caras
            'lanyard-15-2': { 
                mm: { width: 900, height: 15 }, 
                px: { width: 10630, height: 177 },
                safeArea: { top: 25, bottom: 25, left: 1.5, right: 1.5 },
                price: 4.50,
                name: 'Lanyard 15mm (2 caras)'
            },
            'lanyard-20-2': { 
                mm: { width: 900, height: 20 }, 
                px: { width: 10630, height: 236 },
                safeArea: { top: 25, bottom: 25, left: 1.5, right: 1.5 },
                price: 4.75,
                name: 'Lanyard 20mm (2 caras)'
            },
            'lanyard-25-2': { 
                mm: { width: 900, height: 25 }, 
                px: { width: 10630, height: 295 },
                safeArea: { top: 25, bottom: 25, left: 1.5, right: 1.5 },
                price: 5.00,
                name: 'Lanyard 25mm (2 caras)'
            },
            // Llaveros 1 cara
            'llavero-20-1': { 
                mm: { width: 220, height: 20 }, 
                px: { width: 2598, height: 236 },
                safeArea: { top: 15, bottom: 15, left: 1.5, right: 1.5 },
                price: 2.25,
                name: 'Llavero 20mm (1 cara)'
            },
            'llavero-25-1': { 
                mm: { width: 220, height: 25 }, 
                px: { width: 2598, height: 295 },
                safeArea: { top: 15, bottom: 15, left: 1.5, right: 1.5 },
                price: 2.50,
                name: 'Llavero 25mm (1 cara)'
            },
            // Llaveros 2 caras
            'llavero-20-2': { 
                mm: { width: 220, height: 20 }, 
                px: { width: 2598, height: 236 },
                safeArea: { top: 15, bottom: 15, left: 1.5, right: 1.5 },
                price: 3.25,
                name: 'Llavero 20mm (2 caras)'
            },
            'llavero-25-2': { 
                mm: { width: 220, height: 25 }, 
                px: { width: 2598, height: 295 },
                safeArea: { top: 15, bottom: 15, left: 1.5, right: 1.5 },
                price: 3.50,
                name: 'Llavero 25mm (2 caras)'
            },
            // Pulseras 1 cara
            'pulsera-15-1': { 
                mm: { width: 350, height: 15 }, 
                px: { width: 4134, height: 177 },
                safeArea: { top: 15, bottom: 15, left: 1.5, right: 1.5 },
                price: 3.25,
                name: 'Pulsera 15mm (1 cara)'
            },
            'pulsera-20-1': { 
                mm: { width: 350, height: 20 }, 
                px: { width: 4134, height: 236 },
                safeArea: { top: 15, bottom: 15, left: 1.5, right: 1.5 },
                price: 3.50,
                name: 'Pulsera 20mm (1 cara)'
            },
            'pulsera-25-1': { 
                mm: { width: 350, height: 25 }, 
                px: { width: 4134, height: 295 },
                safeArea: { top: 15, bottom: 15, left: 1.5, right: 1.5 },
                price: 3.75,
                name: 'Pulsera 25mm (1 cara)'
            },
            // Pulseras 2 caras
            'pulsera-15-2': { 
                mm: { width: 350, height: 15 }, 
                px: { width: 4134, height: 177 },
                safeArea: { top: 15, bottom: 15, left: 1.5, right: 1.5 },
                price: 4.25,
                name: 'Pulsera 15mm (2 caras)'
            },
            'pulsera-20-2': { 
                mm: { width: 350, height: 20 }, 
                px: { width: 4134, height: 236 },
                safeArea: { top: 15, bottom: 15, left: 1.5, right: 1.5 },
                price: 4.50,
                name: 'Pulsera 20mm (2 caras)'
            },
            'pulsera-25-2': { 
                mm: { width: 350, height: 25 }, 
                px: { width: 4134, height: 295 },
                safeArea: { top: 15, bottom: 15, left: 1.5, right: 1.5 },
                price: 4.75,
                name: 'Pulsera 25mm (2 caras)'
            },
            // Cintas de sombrero
            'sombrero-20-1': { 
                mm: { width: 600, height: 20 }, 
                px: { width: 7087, height: 236 },
                safeArea: { top: 30, bottom: 0, left: 1.5, right: 1.5 },
                price: 4.50,
                name: 'Cinta sombrero 20mm'
            },
            'sombrero-25-1': { 
                mm: { width: 600, height: 25 }, 
                px: { width: 7087, height: 295 },
                safeArea: { top: 30, bottom: 0, left: 1.5, right: 1.5 },
                price: 4.75,
                name: 'Cinta sombrero 25mm'
            },
            // Cintas de coche
            'coche-20-1': { 
                mm: { width: 600, height: 20 }, 
                px: { width: 7087, height: 236 },
                safeArea: { top: 15, bottom: 15, left: 1.5, right: 1.5 },
                price: 4.25,
                name: 'Cinta coche 20mm'
            },
            'coche-25-1': { 
                mm: { width: 600, height: 25 }, 
                px: { width: 7087, height: 295 },
                safeArea: { top: 15, bottom: 15, left: 1.5, right: 1.5 },
                price: 4.50,
                name: 'Cinta coche 25mm'
            },
            // Lazos
            'lazo-20-1': { 
                mm: { width: 300, height: 20 }, 
                px: { width: 3543, height: 236 },
                safeArea: { top: 15, bottom: 15, left: 1.5, right: 1.5 },
                price: 3.75,
                name: 'Lazo 20mm'
            },
            'lazo-25-1': { 
                mm: { width: 300, height: 25 }, 
                px: { width: 3543, height: 295 },
                safeArea: { top: 15, bottom: 15, left: 1.5, right: 1.5 },
                price: 4.00,
                name: 'Lazo 25mm'
            },
            // Cojines
            'cojin-32-silueta': { 
                mm: { width: 340, height: 340 }, 
                px: { width: 4016, height: 4016 },
                safeArea: { top: 15, bottom: 15, left: 15, right: 15 },
                price: 15.50,
                name: 'Cojín 32cm Silueta/3D'
            },
            'cojin-40-1': { 
                mm: { width: 420, height: 420 }, 
                px: { width: 4961, height: 4961 },
                safeArea: { top: 15, bottom: 15, left: 15, right: 15 },
                price: 15.00,
                name: 'Cojín 40cm (1 cara)'
            },
            'cojin-40-2': { 
                mm: { width: 420, height: 420 }, 
                px: { width: 4961, height: 4961 },
                safeArea: { top: 15, bottom: 15, left: 15, right: 15 },
                price: 18.00,
                name: 'Cojín 40cm (2 caras)'
            }
        };

        this.productUrls = {
            // Lanyards
            'lanyard-15-1': 'https://twinsublime.com/producto/lanyard-personalizado-1-cara/',
            'lanyard-20-1': 'https://twinsublime.com/producto/lanyard-personalizado-1-cara/',
            'lanyard-25-1': 'https://twinsublime.com/producto/lanyard-personalizado-1-cara/',
            'lanyard-15-2': 'https://twinsublime.com/producto/lanyard-personalizado-2-caras/',
            'lanyard-20-2': 'https://twinsublime.com/producto/lanyard-personalizado-2-caras/',
            'lanyard-25-2': 'https://twinsublime.com/producto/lanyard-personalizado-2-caras/',
            // Llaveros
            'llavero-20-1': 'https://twinsublime.com/producto/llavero-1-cara/',
            'llavero-25-1': 'https://twinsublime.com/producto/llavero-1-cara/',
            'llavero-20-2': 'https://twinsublime.com/producto/llavero-2-caras/',
            'llavero-25-2': 'https://twinsublime.com/producto/llavero-2-caras/',
            // Pulseras
            'pulsera-15-1': 'https://twinsublime.com/producto/pulsera-1-cara/',
            'pulsera-20-1': 'https://twinsublime.com/producto/pulsera-1-cara/',
            'pulsera-25-1': 'https://twinsublime.com/producto/pulsera-1-cara/',
            'pulsera-15-2': 'https://twinsublime.com/producto/pulsera-2-caras/',
            'pulsera-20-2': 'https://twinsublime.com/producto/pulsera-2-caras/',
            'pulsera-25-2': 'https://twinsublime.com/producto/pulsera-2-caras/',
            // Cintas de sombrero
            'sombrero-20-1': 'https://twinsublime.com/producto/cinta-de-sombrero-1-cara/',
            'sombrero-25-1': 'https://twinsublime.com/producto/cinta-de-sombrero-1-cara/',
            // Cintas de coche
            'coche-20-1': 'https://twinsublime.com/producto/cinta-de-coche-1-cara/',
            'coche-25-1': 'https://twinsublime.com/producto/cinta-de-coche-1-cara/',
            // Lazos
            'lazo-20-1': 'https://twinsublime.com/producto/lazo-1-cara/',
            'lazo-25-1': 'https://twinsublime.com/producto/lazo-1-cara/',
            // Cojines
            'cojin-32-silueta': 'https://twinsublime.com/producto/cojin-3d-silueta/',
            'cojin-40-1': 'https://twinsublime.com/producto/cojin-personalizado-1-cara/',
            'cojin-40-2': 'https://twinsublime.com/producto/cojin-personalizado-2-caras/'
        };

        this.undoStack = [];
        this.redoStack = [];
        this.currentZoom = 1;
        this.isPanMode = false;
        
        this.init();
        this.initKeyboardShortcuts();
    }

    init() {
        this.initWelcomeScreen();
        this.initDesignerScreen();
        this.initPreviewScreen();
    }

    initWelcomeScreen() {
        const userTypeButtons = document.querySelectorAll('.user-type-btn');
        const termsCheckbox = document.getElementById('terms-checkbox');
        const startBtn = document.getElementById('start-design-btn');

        userTypeButtons.forEach(btn => {
            btn.addEventListener('click', () => {
                userTypeButtons.forEach(b => b.classList.remove('selected'));
                btn.classList.add('selected');
                this.userType = btn.dataset.type;
                this.updateStartButton();
            });
        });

        termsCheckbox.addEventListener('change', () => {
            this.updateStartButton();
        });

        startBtn.addEventListener('click', () => {
            if (!startBtn.classList.contains('disabled')) {
                this.goToStep(2);
            }
        });
    }

    updateStartButton() {
        const termsChecked = document.getElementById('terms-checkbox').checked;
        const userSelected = this.userType !== null;
        const startBtn = document.getElementById('start-design-btn');

        if (termsChecked && userSelected) {
            startBtn.classList.remove('disabled');
        } else {
            startBtn.classList.add('disabled');
        }
    }

    initDesignerScreen() {
        this.initProductSelector();
        this.initDesignTools();
    }

    initProductSelector() {
        const productButtons = document.querySelectorAll('.product-btn');
        
        productButtons.forEach(btn => {
            btn.addEventListener('click', () => {
                productButtons.forEach(b => b.classList.remove('selected'));
                btn.classList.add('selected');
                
                this.selectedProduct = btn.dataset.product;
                const templateUrl = btn.dataset.template;
                
                this.loadProductTemplate(templateUrl);
                document.getElementById('preview-3d-btn').disabled = false;
            });
        });
    }

    loadProductTemplate(templateUrl) {
        if (this.canvas) {
            this.canvas.dispose();
        }

        const canvasElement = document.getElementById('design-canvas');
        const placeholder = document.querySelector('.canvas-placeholder');
        
        // Hide placeholder
        placeholder.style.display = 'none';
        
        // Get real dimensions for selected product
        const specs = this.productSpecs[this.selectedProduct];
        if (!specs) return;
        
        // Use scaled dimensions for display (scale down large canvases)
        const maxDisplayWidth = 800;
        const maxDisplayHeight = 600;
        
        let displayWidth = specs.px.width;
        let displayHeight = specs.px.height;
        
        // Scale down if too large for display
        const scaleFactorWidth = maxDisplayWidth / displayWidth;
        const scaleFactorHeight = maxDisplayHeight / displayHeight;
        const scaleFactor = Math.min(scaleFactorWidth, scaleFactorHeight, 1);
        
        displayWidth = Math.round(displayWidth * scaleFactor);
        displayHeight = Math.round(displayHeight * scaleFactor);
        
        canvasElement.width = displayWidth;
        canvasElement.height = displayHeight;
        
        this.canvas = new fabric.Canvas('design-canvas', {
            width: displayWidth,
            height: displayHeight,
            backgroundColor: '#ffffff'
        });

        // Initialize zoom and pan
        this.currentZoom = 1;
        this.isPanMode = false;
        this.setupCanvasInteractions();

        // Update canvas info display
        this.updateCanvasInfo(specs);
        
        // Update product info
        this.updateProductInfo();

        // Add safe area guidelines
        this.addSafeAreaGuides(specs, scaleFactor);

        // Load template as background
        fabric.Image.fromURL(templateUrl, (img) => {
            img.set({
                scaleX: displayWidth / img.width,
                scaleY: displayHeight / img.height,
                selectable: false,
                evented: false,
                excludeFromExport: false,
                opacity: 0.3
            });
            
            this.canvas.setBackgroundImage(img, this.canvas.renderAll.bind(this.canvas));
            this.saveState();
        }, { crossOrigin: 'anonymous' });

        // Set up canvas events for undo/redo
        this.canvas.on('object:added', () => this.saveState());
        this.canvas.on('object:removed', () => this.saveState());
        this.canvas.on('object:modified', () => this.saveState());
    }

    setupCanvasInteractions() {
        if (!this.canvas) return;

        // Mouse wheel zoom
        this.canvas.on('mouse:wheel', (opt) => {
            const delta = opt.e.deltaY;
            let zoom = this.canvas.getZoom();
            zoom *= 0.999 ** delta;
            
            // Limit zoom range
            zoom = Math.max(0.1, Math.min(zoom, 5));
            
            // Zoom towards mouse position
            const point = new fabric.Point(opt.e.offsetX, opt.e.offsetY);
            this.canvas.zoomToPoint(point, zoom);
            
            this.currentZoom = zoom;
            this.updateZoomDisplay();
            opt.e.preventDefault();
            opt.e.stopPropagation();
        });

        // Pan functionality
        this.canvas.on('mouse:down', (opt) => {
            const evt = opt.e;
            if (this.isPanMode || evt.ctrlKey) {
                this.isDragging = true;
                this.canvas.selection = false;
                this.lastPosX = evt.clientX;
                this.lastPosY = evt.clientY;
                this.canvas.defaultCursor = 'grabbing';
            }
        });

        this.canvas.on('mouse:move', (opt) => {
            if (this.isDragging) {
                const e = opt.e;
                const vpt = this.canvas.viewportTransform;
                vpt[4] += e.clientX - this.lastPosX;
                vpt[5] += e.clientY - this.lastPosY;
                this.canvas.requestRenderAll();
                this.lastPosX = e.clientX;
                this.lastPosY = e.clientY;
            }
        });

        this.canvas.on('mouse:up', () => {
            this.canvas.setViewportTransform(this.canvas.viewportTransform);
            this.isDragging = false;
            this.canvas.selection = true;
            this.canvas.defaultCursor = this.isPanMode ? 'grab' : 'default';
        });
    }

    updateCanvasInfo(specs) {
        document.getElementById('canvas-dimensions').textContent = 
            `${specs.mm.width} × ${specs.mm.height} mm (${specs.px.width} × ${specs.px.height} px)`;
    }

    addSafeAreaGuides(specs, scaleFactor) {
        const safeArea = specs.safeArea;
        const strokeWidth = 1;
        const strokeColor = 'rgba(255, 0, 0, 0.5)';
        
        // Convert mm to pixels and apply display scale
        const mmToPx = 300 / 25.4; // 300 DPI conversion
        
        const topSafe = (safeArea.top * mmToPx) * scaleFactor;
        const bottomSafe = this.canvas.height - (safeArea.bottom * mmToPx * scaleFactor);
        const leftSafe = (safeArea.left * mmToPx) * scaleFactor;
        const rightSafe = this.canvas.width - (safeArea.right * mmToPx * scaleFactor);
        
        // Create guide lines
        if (topSafe > 0) {
            const topLine = new fabric.Line([0, topSafe, this.canvas.width, topSafe], {
                stroke: strokeColor,
                strokeWidth: strokeWidth,
                strokeDashArray: [5, 5],
                selectable: false,
                evented: false,
                excludeFromExport: true
            });
            this.canvas.add(topLine);
        }
        
        if (bottomSafe < this.canvas.height) {
            const bottomLine = new fabric.Line([0, bottomSafe, this.canvas.width, bottomSafe], {
                stroke: strokeColor,
                strokeWidth: strokeWidth,
                strokeDashArray: [5, 5],
                selectable: false,
                evented: false,
                excludeFromExport: true
            });
            this.canvas.add(bottomLine);
        }
    }

    updateProductInfo() {
        const infoElement = document.getElementById('selected-product-info');
        if (this.selectedProduct && this.productSpecs[this.selectedProduct]) {
            const specs = this.productSpecs[this.selectedProduct];
            
            infoElement.innerHTML = `
                <div class="product-name">${specs.name}</div>
                <div class="product-dimensions">${specs.mm.width} × ${specs.mm.height} mm</div>
                <div class="product-price">Precio base: €${specs.price.toFixed(2)}</div>
            `;
            infoElement.style.background = '#e8f5e8';
            infoElement.style.borderColor = '#28a745';
        }
    }

    initDesignTools() {
        // Text tools
        document.getElementById('add-text-btn').addEventListener('click', () => {
            this.addText();
        });

        // Image upload
        document.getElementById('upload-image-btn').addEventListener('click', () => {
            document.getElementById('image-upload').click();
        });

        document.getElementById('image-upload').addEventListener('change', (e) => {
            this.handleImageUpload(e);
        });

        // Zoom controls
        document.getElementById('zoom-in-btn').addEventListener('click', () => {
            this.zoomCanvas(1.2);
        });

        document.getElementById('zoom-out-btn').addEventListener('click', () => {
            this.zoomCanvas(0.8);
        });

        document.getElementById('zoom-reset-btn').addEventListener('click', () => {
            this.resetCanvasView();
        });

        document.getElementById('pan-mode-btn').addEventListener('click', () => {
            this.togglePanMode();
        });

        // Enhanced text tools
        document.getElementById('font-family').addEventListener('change', () => {
            this.updateSelectedTextProperties();
        });

        document.getElementById('font-weight').addEventListener('change', () => {
            this.updateSelectedTextProperties();
        });

        document.getElementById('text-color').addEventListener('change', () => {
            this.updateSelectedTextProperties();
        });

        // Image opacity control
        document.getElementById('image-opacity').addEventListener('input', (e) => {
            const activeObj = this.canvas?.getActiveObject();
            if (activeObj && activeObj.type === 'image') {
                activeObj.set('opacity', e.target.value / 100);
                this.canvas.renderAll();
            }
        });

        // Layer controls
        document.getElementById('bring-forward-btn').addEventListener('click', () => {
            const activeObj = this.canvas?.getActiveObject();
            if (activeObj) {
                this.canvas.bringForward(activeObj);
                this.canvas.renderAll();
            }
        });

        document.getElementById('send-backward-btn').addEventListener('click', () => {
            const activeObj = this.canvas?.getActiveObject();
            if (activeObj) {
                this.canvas.sendBackwards(activeObj);
                this.canvas.renderAll();
            }
        });

        document.getElementById('delete-selected-btn').addEventListener('click', () => {
            this.deleteSelected();
        });

        // Undo/Redo
        document.getElementById('undo-btn').addEventListener('click', () => {
            this.undo();
        });

        document.getElementById('redo-btn').addEventListener('click', () => {
            this.redo();
        });

        // Shape tools
        document.querySelectorAll('.shape-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                this.addShape(btn.dataset.shape);
            });
        });

        // Clear canvas
        document.getElementById('clear-canvas-btn').addEventListener('click', () => {
            this.clearCanvas();
        });

        // Preview 3D
        document.getElementById('preview-3d-btn').addEventListener('click', () => {
            this.goToStep(3);
        });

        // Canvas selection events
        this.canvas?.on('selection:created', () => this.updateToolsForSelection());
        this.canvas?.on('selection:updated', () => this.updateToolsForSelection());
        this.canvas?.on('selection:cleared', () => this.hideImageControls());
    }

    updateSelectedTextProperties() {
        const activeObj = this.canvas?.getActiveObject();
        if (activeObj && activeObj.type === 'text') {
            const fontFamily = document.getElementById('font-family').value;
            const fontWeight = document.getElementById('font-weight').value;
            const color = document.getElementById('text-color').value;
            const fontSize = parseInt(document.getElementById('font-size').value);
            
            activeObj.set({
                fontFamily: fontFamily,
                fontWeight: fontWeight,
                fill: color,
                fontSize: fontSize
            });
            
            this.canvas.renderAll();
        }
    }

    updateToolsForSelection() {
        const activeObj = this.canvas?.getActiveObject();
        const imageControls = document.querySelector('.image-controls');
        
        if (activeObj && activeObj.type === 'image') {
            imageControls.style.display = 'block';
            document.getElementById('image-opacity').value = (activeObj.opacity || 1) * 100;
        } else {
            imageControls.style.display = 'none';
        }
    }

    hideImageControls() {
        document.querySelector('.image-controls').style.display = 'none';
    }

    addText() {
        if (!this.canvas) return;

        const text = document.getElementById('text-input').value || 'Texto de ejemplo';
        const color = document.getElementById('text-color').value;
        const fontSize = parseInt(document.getElementById('font-size').value);
        const fontFamily = document.getElementById('font-family').value;
        const fontWeight = document.getElementById('font-weight').value;

        const textObj = new fabric.Text(text, {
            left: this.canvas.width / 2,
            top: this.canvas.height / 2,
            originX: 'center',
            originY: 'center',
            fill: color,
            fontSize: fontSize,
            fontFamily: fontFamily,
            fontWeight: fontWeight
        });

        this.canvas.add(textObj);
        this.canvas.setActiveObject(textObj);
        this.canvas.renderAll();
        
        // Clear text input
        document.getElementById('text-input').value = '';
    }

    handleImageUpload(event) {
        if (!this.canvas) return;

        const file = event.target.files[0];
        if (!file) return;

        const reader = new FileReader();
        reader.onload = (e) => {
            fabric.Image.fromURL(e.target.result, (img) => {
                const maxSize = 200;
                const scale = Math.min(maxSize / img.width, maxSize / img.height);
                
                img.set({
                    left: this.canvas.width / 2,
                    top: this.canvas.height / 2,
                    originX: 'center',
                    originY: 'center',
                    scaleX: scale,
                    scaleY: scale
                });

                this.canvas.add(img);
                this.canvas.setActiveObject(img);
                this.canvas.renderAll();
            });
        };
        reader.readAsDataURL(file);
    }

    addShape(shapeType) {
        if (!this.canvas) return;

        const color = document.getElementById('shape-color').value;
        let shape;

        const centerX = this.canvas.width / 2;
        const centerY = this.canvas.height / 2;

        if (shapeType === 'rect') {
            shape = new fabric.Rect({
                left: centerX,
                top: centerY,
                originX: 'center',
                originY: 'center',
                width: 100,
                height: 60,
                fill: color,
                stroke: '#333',
                strokeWidth: 1
            });
        } else if (shapeType === 'circle') {
            shape = new fabric.Circle({
                left: centerX,
                top: centerY,
                originX: 'center',
                originY: 'center',
                radius: 50,
                fill: color,
                stroke: '#333',
                strokeWidth: 1
            });
        } else if (shapeType === 'triangle') {
            shape = new fabric.Triangle({
                left: centerX,
                top: centerY,
                originX: 'center',
                originY: 'center',
                width: 80,
                height: 80,
                fill: color,
                stroke: '#333',
                strokeWidth: 1
            });
        } else if (shapeType === 'star') {
            const points = this.createStarPoints(50, 5);
            shape = new fabric.Polygon(points, {
                left: centerX,
                top: centerY,
                originX: 'center',
                originY: 'center',
                fill: color,
                stroke: '#333',
                strokeWidth: 1
            });
        }

        if (shape) {
            this.canvas.add(shape);
            this.canvas.setActiveObject(shape);
            this.canvas.renderAll();
        }
    }

    createStarPoints(radius, points) {
        const starPoints = [];
        const step = (Math.PI * 2) / points;
        const innerRadius = radius * 0.5;
        
        for (let i = 0; i < points * 2; i++) {
            const r = i % 2 === 0 ? radius : innerRadius;
            const angle = i * step / 2 - Math.PI / 2;
            starPoints.push({
                x: Math.cos(angle) * r,
                y: Math.sin(angle) * r
            });
        }
        return starPoints;
    }

    saveState() {
        if (!this.canvas) return;
        
        this.undoStack.push(JSON.stringify(this.canvas.toJSON()));
        this.redoStack = [];
        
        // Limit undo stack size
        if (this.undoStack.length > 50) {
            this.undoStack.shift();
        }
    }

    undo() {
        if (!this.canvas || this.undoStack.length <= 1) return;
        
        this.redoStack.push(this.undoStack.pop());
        const previousState = this.undoStack[this.undoStack.length - 1];
        
        if (previousState) {
            this.canvas.loadFromJSON(previousState, () => {
                this.canvas.renderAll();
            });
        }
    }

    redo() {
        if (!this.canvas || this.redoStack.length === 0) return;
        
        const nextState = this.redoStack.pop();
        this.undoStack.push(nextState);
        
        this.canvas.loadFromJSON(nextState, () => {
            this.canvas.renderAll();
        });
    }

    initPreviewScreen() {
        document.getElementById('download-design-btn').addEventListener('click', () => {
            this.downloadDesign();
        });

        document.getElementById('back-to-edit-btn').addEventListener('click', () => {
            this.goToStep(2);
        });

        document.getElementById('add-to-cart-btn').addEventListener('click', () => {
            this.addToCart();
        });
    }

    init3DPreview() {
        const container = document.getElementById('three-container');
        
        // Clear previous scene
        if (this.renderer) {
            container.removeChild(this.renderer.domElement);
        }

        // Scene setup
        this.scene = new THREE.Scene();
        this.scene.background = new THREE.Color(0xf0f0f0);

        // Camera
        this.camera = new THREE.PerspectiveCamera(75, container.clientWidth / container.clientHeight, 0.1, 1000);
        this.camera.position.set(0, 0, 5);

        // Renderer
        this.renderer = new THREE.WebGLRenderer({ antialias: true });
        this.renderer.setSize(container.clientWidth, container.clientHeight);
        this.renderer.shadowMap.enabled = true;
        this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
        container.appendChild(this.renderer.domElement);

        // Lighting
        const ambientLight = new THREE.AmbientLight(0xffffff, 0.6);
        this.scene.add(ambientLight);

        const directionalLight = new THREE.DirectionalLight(0xffffff, 0.8);
        directionalLight.position.set(10, 10, 5);
        directionalLight.castShadow = true;
        this.scene.add(directionalLight);

        // Initialize 3D controls
        this.init3DControls(container);

        // Create 3D representation of the product
        this.create3DProduct();

        // Animation loop
        const animate = () => {
            requestAnimationFrame(animate);
            this.renderer.render(this.scene, this.camera);
        };
        animate();

        // Handle resize
        window.addEventListener('resize', () => {
            this.camera.aspect = container.clientWidth / container.clientHeight;
            this.camera.updateProjectionMatrix();
            this.renderer.setSize(container.clientWidth, container.clientHeight);
        });
    }

    init3DControls(container) {
        let isMouseDown = false;
        let mouseX = 0, mouseY = 0;
        let targetRotationX = 0, targetRotationY = 0;
        let currentRotationX = 0, currentRotationY = 0;
        let cameraDistance = 5;
        
        // Mouse controls for 3D scene
        const onMouseDown = (event) => {
            isMouseDown = true;
            mouseX = event.clientX;
            mouseY = event.clientY;
        };

        const onMouseMove = (event) => {
            if (!isMouseDown) return;
            
            const deltaX = event.clientX - mouseX;
            const deltaY = event.clientY - mouseY;
            
            targetRotationY += deltaX * 0.01;
            targetRotationX += deltaY * 0.01;
            
            // Clamp vertical rotation
            targetRotationX = Math.max(-Math.PI / 2, Math.min(Math.PI / 2, targetRotationX));
            
            mouseX = event.clientX;
            mouseY = event.clientY;
        };

        const onMouseUp = () => {
            isMouseDown = false;
        };

        const onWheel = (event) => {
            event.preventDefault();
            cameraDistance += event.deltaY * 0.01;
            cameraDistance = Math.max(2, Math.min(20, cameraDistance));
            
            // Update camera position
            this.camera.position.x = Math.sin(targetRotationY) * cameraDistance;
            this.camera.position.z = Math.cos(targetRotationY) * cameraDistance;
            this.camera.position.y = Math.sin(targetRotationX) * cameraDistance;
            this.camera.lookAt(0, 0, 0);
        };

        // Add event listeners
        container.addEventListener('mousedown', onMouseDown);
        container.addEventListener('mousemove', onMouseMove);
        container.addEventListener('mouseup', onMouseUp);
        container.addEventListener('wheel', onWheel);
        container.addEventListener('mouseleave', onMouseUp);

        // Smooth camera movement animation
        const updateCamera = () => {
            currentRotationX += (targetRotationX - currentRotationX) * 0.1;
            currentRotationY += (targetRotationY - currentRotationY) * 0.1;
            
            this.camera.position.x = Math.sin(currentRotationY) * cameraDistance;
            this.camera.position.z = Math.cos(currentRotationY) * cameraDistance;
            this.camera.position.y = Math.sin(currentRotationX) * cameraDistance;
            this.camera.lookAt(0, 0, 0);
            
            requestAnimationFrame(updateCamera);
        };
        updateCamera();
    }

    create3DProduct() {
        if (!this.canvas || !this.selectedProduct) return;

        // Clear previous objects
        while(this.scene.children.length > 2) {
            this.scene.remove(this.scene.children[2]);
        }

        // Get design as high-resolution texture
        const canvasElement = this.canvas.getElement();
        const texture = new THREE.CanvasTexture(canvasElement);
        texture.flipY = false;
        texture.wrapS = THREE.RepeatWrapping;
        texture.wrapT = THREE.RepeatWrapping;

        let geometry, material, mesh;
        const specs = this.productSpecs[this.selectedProduct];

        if (this.selectedProduct.includes('cojin')) {
            // Enhanced cushion with proper proportions
            const aspectRatio = specs.mm.width / specs.mm.height;
            geometry = new THREE.BoxGeometry(3 * aspectRatio, 3, 0.8, 16, 16, 8);
            
            // Add subtle fabric texture
            material = [
                new THREE.MeshLambertMaterial({ 
                    map: texture,
                    roughness: 0.8,
                    metalness: 0.1
                }), // front
                new THREE.MeshLambertMaterial({ color: 0xf5f5f5 }), // back
                new THREE.MeshLambertMaterial({ color: 0xe8e8e8 }), // top
                new THREE.MeshLambertMaterial({ color: 0xe8e8e8 }), // bottom
                new THREE.MeshLambertMaterial({ color: 0xdcdcdc }), // right
                new THREE.MeshLambertMaterial({ color: 0xdcdcdc })  // left
            ];
            mesh = new THREE.Mesh(geometry, material);
            
        } else if (this.selectedProduct.includes('lanyard')) {
            // More realistic lanyard with proper proportions
            const group = new THREE.Group();
            
            // Calculate real proportions
            const length = 4;
            const width = (specs.mm.height / specs.mm.width) * length;
            
            // Main strap with rounded edges
            geometry = new THREE.BoxGeometry(width, 0.02, length, 8, 1, 32);
            material = new THREE.MeshLambertMaterial({ 
                map: texture,
                roughness: 0.6
            });
            mesh = new THREE.Mesh(geometry, material);
            mesh.rotation.x = Math.PI / 2;
            group.add(mesh);
            
            // Metal clip with realistic appearance
            const clipGeometry = new THREE.BoxGeometry(width * 1.2, 0.05, 0.3);
            const clipMaterial = new THREE.MeshLambertMaterial({ 
                color: 0x444444,
                metalness: 0.8,
                roughness: 0.2
            });
            const clip = new THREE.Mesh(clipGeometry, clipMaterial);
            clip.position.z = -2.2;
            group.add(clip);
            
            mesh = group;
            
        } else if (this.selectedProduct.includes('pulsera')) {
            // Enhanced bracelet with realistic bend
            const radius = 1.2;
            const tubeRadius = specs.mm.height * 0.002; // Scale to 3D
            
            geometry = new THREE.TorusGeometry(radius, tubeRadius, 8, 64);
            material = new THREE.MeshLambertMaterial({ 
                map: texture,
                roughness: 0.7
            });
            mesh = new THREE.Mesh(geometry, material);
            mesh.rotation.x = Math.PI / 2;
            
        } else if (this.selectedProduct.includes('llavero')) {
            // More detailed keychain
            const group = new THREE.Group();
            
            // Main tag with rounded corners
            const aspectRatio = specs.mm.width / specs.mm.height;
            geometry = new THREE.BoxGeometry(1.5 * aspectRatio, 1.5, 0.05, 16, 16, 1);
            material = new THREE.MeshLambertMaterial({ 
                map: texture, 
                side: THREE.DoubleSide,
                roughness: 0.3
            });
            mesh = new THREE.Mesh(geometry, material);
            group.add(mesh);
            
            // Metal ring with realistic material
            const ringGeometry = new THREE.TorusGeometry(0.15, 0.02, 8, 16);
            const ringMaterial = new THREE.MeshLambertMaterial({ 
                color: 0x888888,
                metalness: 0.9,
                roughness: 0.1
            });
            const ring = new THREE.Mesh(ringGeometry, ringMaterial);
            ring.position.y = 0.9;
            ring.rotation.x = Math.PI / 2;
            group.add(ring);
            
            mesh = group;
            
        } else if (this.selectedProduct.includes('sombrero')) {
            // Hat band as curved strip around invisible hat
            const radius = 1.5;
            geometry = new THREE.CylinderGeometry(radius, radius, specs.mm.height * 0.004, 32, 1, true);
            material = new THREE.MeshLambertMaterial({ 
                map: texture,
                side: THREE.DoubleSide,
                transparent: false,
                roughness: 0.7
            });
            mesh = new THREE.Mesh(geometry, material);
            
            // Add invisible hat for context
            const hatGeometry = new THREE.CylinderGeometry(radius * 0.98, radius * 0.98, 0.02, 32);
            const hatMaterial = new THREE.MeshLambertMaterial({ 
                color: 0x8B4513,
                transparent: true,
                opacity: 0.3
            });
            const hat = new THREE.Mesh(hatGeometry, hatMaterial);
            hat.position.y = -specs.mm.height * 0.002;
            mesh.add(hat);
            
        } else {
            // Default representation
            geometry = new THREE.PlaneGeometry(2, 3);
            material = new THREE.MeshLambertMaterial({ 
                map: texture, 
                side: THREE.DoubleSide 
            });
            mesh = new THREE.Mesh(geometry, material);
        }

        mesh.castShadow = true;
        mesh.receiveShadow = true;
        
        // Add to scene
        this.scene.add(mesh);
        
        // Auto-fit camera
        this.fitCameraToObject();
    }

    fitCameraToObject() {
        if (!this.scene.children.length) return;
        
        const box = new THREE.Box3().setFromObject(this.scene.children[this.scene.children.length - 1]);
        const size = box.getSize(new THREE.Vector3()).length();
        const center = box.getCenter(new THREE.Vector3());
        
        this.camera.position.copy(center);
        this.camera.position.x += size;
        this.camera.position.y += size * 0.5;
        this.camera.position.z += size;
        this.camera.lookAt(center);
    }

    downloadDesign() {
        if (!this.canvas) return;

        // Get original dimensions for export
        const specs = this.productSpecs[this.selectedProduct];
        if (!specs) return;

        // Create high-resolution export canvas
        const exportCanvas = new fabric.Canvas(null, {
            width: specs.px.width,
            height: specs.px.height,
            backgroundColor: 'transparent'
        });

        // Calculate scale factor from display to export size
        const scaleFactor = specs.px.width / this.canvas.width;

        // Clone and scale all design objects
        const designObjects = this.canvas.getObjects().filter(obj => 
            obj !== this.canvas.backgroundImage && !obj.excludeFromExport
        );

        let objectsToProcess = designObjects.length;
        if (objectsToProcess === 0) {
            alert('No hay elementos de diseño para descargar');
            return;
        }

        designObjects.forEach(obj => {
            obj.clone(clonedObj => {
                // Scale up for high-resolution export
                clonedObj.set({
                    left: clonedObj.left * scaleFactor,
                    top: clonedObj.top * scaleFactor,
                    scaleX: (clonedObj.scaleX || 1) * scaleFactor,
                    scaleY: (clonedObj.scaleY || 1) * scaleFactor
                });
                
                if (clonedObj.type === 'text') {
                    clonedObj.set({
                        fontSize: clonedObj.fontSize * scaleFactor
                    });
                }
                
                exportCanvas.add(clonedObj);
                
                objectsToProcess--;
                if (objectsToProcess === 0) {
                    this.exportHighResCanvas(exportCanvas, specs);
                }
            });
        });
    }

    exportHighResCanvas(exportCanvas, specs) {
        setTimeout(() => {
            const dataURL = exportCanvas.toDataURL({
                format: 'png',
                quality: 1.0,
                multiplier: 1 // Already at target resolution
            });

            const link = document.createElement('a');
            link.download = `twinsublime_${this.selectedProduct}_${specs.mm.width}x${specs.mm.height}mm_300dpi.png`;
            link.href = dataURL;
            link.click();

            exportCanvas.dispose();
        }, 100);
    }

    addToCart() {
        if (!this.selectedProduct || !this.productUrls[this.selectedProduct]) return;

        // In a real implementation, you would send the design data to your backend
        // and redirect to the product page with the design data
        
        // For now, redirect to the product URL
        window.open(this.productUrls[this.selectedProduct], '_blank');
    }

    goToStep(step) {
        // Hide current screen
        document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
        
        // Show target screen
        if (step === 2) {
            document.getElementById('designer-screen').classList.add('active');
            this.updateProgressIndicator(1);
        } else if (step === 3) {
            document.getElementById('preview-screen').classList.add('active');
            this.updateProgressIndicator(2);
            setTimeout(() => this.init3DPreview(), 500);
        }
        
        this.currentStep = step;
    }

    updateProgressIndicator(activeIndex) {
        document.querySelectorAll('.step').forEach((step, index) => {
            if (index <= activeIndex) {
                step.classList.add('active');
            } else {
                step.classList.remove('active');
            }
        });
    }

    initKeyboardShortcuts() {
        document.addEventListener('keydown', (e) => {
            // Prevent default browser actions for our shortcuts
            if (e.ctrlKey || e.metaKey) {
                switch(e.key.toLowerCase()) {
                    case 'z':
                        e.preventDefault();
                        this.undo();
                        break;
                    case 'y':
                        e.preventDefault();
                        this.redo();
                        break;
                    case 'd':
                        e.preventDefault();
                        this.downloadDesign();
                        break;
                    case 'p':
                        e.preventDefault();
                        if (this.selectedProduct) {
                            this.goToStep(3);
                        }
                        break;
                    case '=':
                    case '+':
                        e.preventDefault();
                        this.zoomCanvas(1.2);
                        break;
                    case '-':
                        e.preventDefault();
                        this.zoomCanvas(0.8);
                        break;
                    case ' ':
                        e.preventDefault();
                        this.togglePanMode();
                        break;
                    case '0':
                        e.preventDefault();
                        this.resetCanvasView();
                        break;
                }
            }

            // Delete keys
            if (e.key === 'Delete') {
                if (e.shiftKey) {
                    e.preventDefault();
                    this.clearCanvas();
                } else {
                    e.preventDefault();
                    this.deleteSelected();
                }
            }

            // Tab switching
            if (e.key === 'Tab') {
                e.preventDefault();
                this.switchTabs();
            }
        });
    }

    zoomCanvas(factor) {
        if (!this.canvas) return;
        
        const center = new fabric.Point(this.canvas.width / 2, this.canvas.height / 2);
        const zoom = this.canvas.getZoom() * factor;
        const newZoom = Math.max(0.1, Math.min(zoom, 5));
        
        this.canvas.zoomToPoint(center, newZoom);
        this.currentZoom = newZoom;
        this.updateZoomDisplay();
        this.canvas.renderAll();
    }

    resetCanvasView() {
        if (!this.canvas) return;
        
        this.canvas.setViewportTransform([1, 0, 0, 1, 0, 0]);
        this.canvas.setZoom(1);
        this.currentZoom = 1;
        this.updateZoomDisplay();
        this.canvas.renderAll();
    }

    togglePanMode() {
        this.isPanMode = !this.isPanMode;
        const panBtn = document.getElementById('pan-mode-btn');
        
        if (this.isPanMode) {
            panBtn.classList.add('active');
            if (this.canvas) {
                this.canvas.selection = false;
                this.canvas.defaultCursor = 'grab';
                this.canvas.hoverCursor = 'grab';
            }
        } else {
            panBtn.classList.remove('active');
            if (this.canvas) {
                this.canvas.selection = true;
                this.canvas.defaultCursor = 'default';
                this.canvas.hoverCursor = 'move';
            }
        }
    }

    updateZoomDisplay() {
        const zoomPercent = Math.round(this.currentZoom * 100);
        document.getElementById('zoom-level').textContent = `${zoomPercent}%`;
    }

    switchTabs() {
        // Cycle through main tool groups
        const toolGroups = document.querySelectorAll('.tool-group');
        // Simple implementation - could be enhanced
        console.log('Tab switching - implement tab focus cycling');
    }
}

// Initialize the application
document.addEventListener('DOMContentLoaded', () => {
    new DesignLab();
});